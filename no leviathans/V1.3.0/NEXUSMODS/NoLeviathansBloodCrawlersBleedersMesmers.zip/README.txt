Thanks for installing No Leviathans.

To install copy the BepInEx folder into your main subnautica folder, if you do it correctly the files will merge.

DDE-64-bit